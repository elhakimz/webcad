import { initOpenCascade } from "opencascade.js";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let oc: any = null;

self.onmessage = async (e) => {
  const { type, payload, id } = e.data;

  if (type === 'init') {
    if (!oc) {
      try {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        oc = await (initOpenCascade as any)();
        self.postMessage({ type: 'init', success: true, id });
      } catch (error: any) {
        self.postMessage({ type: 'init', success: false, error: error.message, id });
      }
    } else {
      self.postMessage({ type: 'init', success: true, id });
    }
  } else if (type === 'createBox') {
    if (!oc) {
      self.postMessage({ type: 'error', error: 'Not initialized', id });
      return;
    }
    const { x, y, z, dx, dy, dz, deflection } = payload;
    try {
      const pt = new oc.gp_Pnt_3(x, y, z);
      const box = new oc.BRepPrimAPI_MakeBox_2(pt, dx, dy, dz);
      const shape = box.Shape();

      // Tessellate and get geometry data
      const geometryData = shapeToBufferGeometryData(shape, oc, deflection);

      pt.delete();
      box.delete();

      if (geometryData.positions.length === 0) {
        throw new Error("No geometry generated from shape. Positions array is empty.");
      }

      self.postMessage({ type: 'createBox', success: true, payload: geometryData, id });
    } catch (error: any) {
      const errorMessage = error.message || error.toString() || 'Unknown error';
      self.postMessage({ type: 'createBox', success: false, error: errorMessage, id });
    }
  } else if (type === 'createCylinder') {
    if (!oc) {
      self.postMessage({ type: 'error', error: 'Not initialized', id });
      return;
    }
    const { x, y, z, r, h, deflection } = payload;
    try {
      // Use constructor with 3 parameters: Radius, Height, Angle
      const cylinder = new oc.BRepPrimAPI_MakeCylinder_2(r, h, 2 * Math.PI);
      let shape = cylinder.Shape();

      // Translate to (x, y, z)
      if (x !== 0 || y !== 0 || z !== 0) {
        const translation = new oc.gp_Vec_4(x, y, z);
        const transform = new oc.gp_Trsf_1();
        transform.SetTranslation_1(translation);
        const brepTransform = new oc.BRepBuilderAPI_Transform_2(shape, transform, true);
        shape = brepTransform.Shape();
        translation.delete();
        transform.delete();
        brepTransform.delete();
      }

      // Tessellate and get geometry data
      const geometryData = shapeToBufferGeometryData(shape, oc, deflection);

      cylinder.delete();

      if (geometryData.positions.length === 0) {
        throw new Error("No geometry generated from shape. Positions array is empty.");
      }

      self.postMessage({ type: 'createCylinder', success: true, payload: geometryData, id });
    } catch (error: any) {
      const errorMessage = error.message || error.toString() || 'Unknown error';
      self.postMessage({ type: 'createCylinder', success: false, error: errorMessage, id });
    }
  } else if (type === 'createSphere') {
    if (!oc) {
      self.postMessage({ type: 'error', error: 'Not initialized', id });
      return;
    }
    const { x, y, z, r, deflection } = payload;
    try {
      // Use constructor with 1 parameter: Radius (creates at origin)
      const sphere = new oc.BRepPrimAPI_MakeSphere_1(r);
      let shape = sphere.Shape();

      // Translate to (x, y, z)
      if (x !== 0 || y !== 0 || z !== 0) {
        const translation = new oc.gp_Vec_4(x, y, z);
        const transform = new oc.gp_Trsf_1();
        transform.SetTranslation_1(translation);
        const brepTransform = new oc.BRepBuilderAPI_Transform_2(shape, transform, true);
        shape = brepTransform.Shape();
        translation.delete();
        transform.delete();
        brepTransform.delete();
      }

      // Tessellate and get geometry data
      const geometryData = shapeToBufferGeometryData(shape, oc, deflection);

      sphere.delete();

      if (geometryData.positions.length === 0) {
        throw new Error("No geometry generated from shape. Positions array is empty.");
      }

      self.postMessage({ type: 'createSphere', success: true, payload: geometryData, id });
    } catch (error: any) {
      const errorMessage = error.message || error.toString() || 'Unknown error';
      self.postMessage({ type: 'createSphere', success: false, error: errorMessage, id });
    }
  } else if (type === 'createCone') {
    if (!oc) {
      self.postMessage({ type: 'error', error: 'Not initialized', id });
      return;
    }
    const { x, y, z, r, h, deflection } = payload;
    try {
      // Try BRepPrimAPI_MakeCone_1
      const cone = new oc.BRepPrimAPI_MakeCone_1(r, 0, h);
      let shape = cone.Shape();

      // Translate to (x, y, z)
      if (x !== 0 || y !== 0 || z !== 0) {
        const translation = new oc.gp_Vec_4(x, y, z);
        const transform = new oc.gp_Trsf_1();
        transform.SetTranslation_1(translation);
        const brepTransform = new oc.BRepBuilderAPI_Transform_2(shape, transform, true);
        shape = brepTransform.Shape();
        translation.delete();
        transform.delete();
        brepTransform.delete();
      }

      // Tessellate and get geometry data
      const geometryData = shapeToBufferGeometryData(shape, oc, deflection);

      cone.delete();

      if (geometryData.positions.length === 0) {
        throw new Error("No geometry generated from shape. Positions array is empty.");
      }

      self.postMessage({ type: 'createCone', success: true, payload: geometryData, id });
    } catch (error: any) {
      const errorMessage = error.message || error.toString() || 'Unknown error';
      self.postMessage({ type: 'createCone', success: false, error: errorMessage, id });
    }
  } else if (type === 'createTorus') {
    if (!oc) {
      self.postMessage({ type: 'error', error: 'Not initialized', id });
      return;
    }
    const { x, y, z, r1, r2, deflection } = payload;
    try {
      // Try BRepPrimAPI_MakeTorus_1
      const torus = new oc.BRepPrimAPI_MakeTorus_1(r1, r2);
      let shape = torus.Shape();

      // Translate to (x, y, z)
      if (x !== 0 || y !== 0 || z !== 0) {
        const translation = new oc.gp_Vec_4(x, y, z);
        const transform = new oc.gp_Trsf_1();
        transform.SetTranslation_1(translation);
        const brepTransform = new oc.BRepBuilderAPI_Transform_2(shape, transform, true);
        shape = brepTransform.Shape();
        translation.delete();
        transform.delete();
        brepTransform.delete();
      }

      // Tessellate and get geometry data
      const geometryData = shapeToBufferGeometryData(shape, oc, deflection);

      torus.delete();

      if (geometryData.positions.length === 0) {
        throw new Error("No geometry generated from shape. Positions array is empty.");
      }

      self.postMessage({ type: 'createTorus', success: true, payload: geometryData, id });
    } catch (error: any) {
      const errorMessage = error.message || error.toString() || 'Unknown error';
      self.postMessage({ type: 'createTorus', success: false, error: errorMessage, id });
    }
  } else if (type === 'createExtrude') {
    if (!oc) {
      self.postMessage({ type: 'error', error: 'Not initialized', id });
      return;
    }
    const { points, height, thickness, deflection, isClosed } = payload;

    try {
      let resultShape: any = null;

      if (thickness > 0) {
        // Sheet-based design: create thick face for each segment and extrude
        const shapes: any[] = [];
        for (let i = 0; i < points.length - 1; i++) {
          const p1 = points[i];
          const p2 = points[i + 1];
          const dx = p2.x - p1.x;
          const dy = p2.y - p1.y;
          const len = Math.sqrt(dx * dx + dy * dy);
          if (len < 1e-6) continue;

          const pts = [
            new oc.gp_Pnt_3(0, -thickness/2, 0),
            new oc.gp_Pnt_3(len, -thickness/2, 0),
            new oc.gp_Pnt_3(len, thickness/2, 0),
            new oc.gp_Pnt_3(0, thickness/2, 0)
          ];
          
          const e0 = new oc.BRepBuilderAPI_MakeEdge_3(pts[0], pts[1]);
          const makeWire = new oc.BRepBuilderAPI_MakeWire_2(e0.Edge());
          e0.delete();

          
          for (let j = 1; j < 4; j++) {
            const e = new oc.BRepBuilderAPI_MakeEdge_3(pts[j], pts[(j+1)%4]);
            makeWire.Add_1(e.Edge());
            e.delete();
          }


          const wire = makeWire.Wire();

          const faceMaker = new oc.BRepBuilderAPI_MakeFace_2(wire);
          const face = faceMaker.Face();


          // Transform face to match segment
          const angle = Math.atan2(dy, dx);
          const trsf = new oc.gp_Trsf_1();
          const axis = new oc.gp_Ax1_2(new oc.gp_Pnt_3(0, 0, 0), new oc.gp_Dir_3(0, 0, 1));
          trsf.SetRotation(axis, angle);
          trsf.SetTranslation_1(new oc.gp_Vec_4(p1.x, p1.y, p1.z));
          
          const transformer = new oc.BRepBuilderAPI_Transform_2(face, trsf, true);
          const transformedFace = transformer.Shape();

          shapes.push(transformedFace);



          // Cleanup
          pts.forEach(p => p.delete());
          makeWire.delete();
          wire.delete();
          faceMaker.delete();
          face.delete();
          trsf.delete();
          axis.delete();
          transformer.delete();
        }


        // Fuse all segment faces into a single profile face
        if (shapes.length > 0) {
          let profileFace = shapes[0];
          for (let i = 1; i < shapes.length; i++) {
            const fuse = new oc.BRepAlgoAPI_Fuse(profileFace, shapes[i]);
            fuse.Build();
            if (fuse.IsDone()) {
              profileFace = fuse.Shape();
            }
            fuse.delete();
          }
          
          const dirVec = new oc.gp_Vec_4(0, 0, height);
          const builder = new oc.BRepPrimAPI_MakePrism_2(profileFace, dirVec);



          resultShape = builder.Shape();


          dirVec.delete();
          builder.delete();
        }

      } else {
        // Standard extrusion (closed profile -> solid, open -> surface)
        const p0 = new oc.gp_Pnt_3(points[0].x, points[0].y, points[0].z);
        const p1 = new oc.gp_Pnt_3(points[1].x, points[1].y, points[1].z);
        const e0 = new oc.BRepBuilderAPI_MakeEdge_3(p0, p1);
        const makeWire = new oc.BRepBuilderAPI_MakeWire_2(e0.Edge());
        p0.delete();

        p1.delete();
        e0.delete();

        
        for (let i = 1; i < points.length - 1; i++) {
          const pi = new oc.gp_Pnt_3(points[i].x, points[i].y, points[i].z);
          const pi1 = new oc.gp_Pnt_3(points[i+1].x, points[i+1].y, points[i+1].z);
          const makeEdge = new oc.BRepBuilderAPI_MakeEdge_3(pi, pi1);
          if (makeEdge.IsDone()) {
            makeWire.Add_1(makeEdge.Edge());
          }
          pi.delete();
          pi1.delete();
          makeEdge.delete();
        }
        let profile: any = makeWire.Wire();
        if (isClosed) {
          const faceMaker = new oc.BRepBuilderAPI_MakeFace_2(profile);



          if (faceMaker.IsDone()) {

            profile = faceMaker.Face();
          } else {
            faceMaker.delete();
            throw new Error("Failed to create face from closed profile.");
          }
          faceMaker.delete();
        }


        const dirVec = new oc.gp_Vec_4(0, 0, height);
        const builder = new oc.BRepPrimAPI_MakePrism_1(profile, dirVec, false, true);
        resultShape = builder.Shape();

        makeWire.delete();
        profile.delete();
        dirVec.delete();
        builder.delete();

      }

      if (!resultShape) {
        throw new Error("Failed to create extrude shape.");
      }

      // Mock geometry data to test if creation fails
      const geometryData = { positions: [], indices: [] };
      // const geometryData = shapeToBufferGeometryData(resultShape, oc, deflection);
      // resultShape.delete();


      self.postMessage({ type: 'createExtrude', success: true, payload: geometryData, id });
    } catch (error: any) {
      const errorMessage = error.message || error.toString() || 'Unknown error';
      self.postMessage({ type: 'createExtrude', success: false, error: errorMessage, id });
    }
  } else if (type === 'createRevolve') {
    if (!oc) {
      self.postMessage({ type: 'error', error: 'Not initialized', id });
      return;
    }
    const { points, axisPoint, axisDir, angle, thickness, deflection } = payload;
    try {
      let resultShape: any = null;
      const angleRad = angle * Math.PI / 180;
      const revAxis = new oc.gp_Ax1_2(new oc.gp_Pnt_3(axisPoint.x, axisPoint.y, axisPoint.z), new oc.gp_Dir_3(axisDir.x, axisDir.y, axisDir.z));

      if (thickness > 0) {
        // Sheet-based design: create thick face for each segment and revolve
        const shapes: any[] = [];
        for (let i = 0; i < points.length - 1; i++) {
          const p1 = points[i];
          const p2 = points[i + 1];
          const dx = p2.x - p1.x;
          const dy = p2.y - p1.y;
          const len = Math.sqrt(dx * dx + dy * dy);
          if (len < 1e-6) continue;

          const pts = [
            new oc.gp_Pnt_3(0, -thickness/2, 0),
            new oc.gp_Pnt_3(len, -thickness/2, 0),
            new oc.gp_Pnt_3(len, thickness/2, 0),
            new oc.gp_Pnt_3(0, thickness/2, 0)
          ];
          
          const e0 = new oc.BRepBuilderAPI_MakeEdge_3(pts[0], pts[1]);
          const makeWire = new oc.BRepBuilderAPI_MakeWire_2(e0.Edge());
          e0.delete();

          
          for (let j = 1; j < 4; j++) {
            const e = new oc.BRepBuilderAPI_MakeEdge_3(pts[j], pts[(j+1)%4]);
            makeWire.Add_1(e.Edge());
            e.delete();
          }


          const wire = makeWire.Wire();

          const faceMaker = new oc.BRepBuilderAPI_MakeFace_2(wire);
          const face = faceMaker.Face();

          // Transform face to match segment
          const rotAngle = Math.atan2(dy, dx);
          const trsf = new oc.gp_Trsf_1();
          const rotAxis = new oc.gp_Ax1_2(new oc.gp_Pnt_3(0, 0, 0), new oc.gp_Dir_3(0, 0, 1));
          trsf.SetRotation(rotAxis, rotAngle);
          trsf.SetTranslation_1(new oc.gp_Vec_4(p1.x, p1.y, p1.z));
          
          const transformer = new oc.BRepBuilderAPI_Transform_2(face, trsf, true);
          const transformedFace = transformer.Shape();

          // Revolve face
          const builder = new oc.BRepPrimAPI_MakeRevol_2(transformedFace, revAxis, angleRad);
          shapes.push(builder.Shape());

          // Cleanup
          pts.forEach(p => p.delete());
          makeWire.delete();
          wire.delete();
          faceMaker.delete();
          face.delete();
          trsf.delete();
          rotAxis.delete();
          transformer.delete();
          builder.delete();
        }

        // Fuse all segments
        if (shapes.length > 0) {
          resultShape = shapes[0];
          for (let i = 1; i < shapes.length; i++) {
            const fuse = new oc.BRepAlgoAPI_Fuse(resultShape, shapes[i]);
            fuse.Build();
            if (fuse.IsDone()) {
              resultShape = fuse.Shape();
            }
            fuse.delete();
          }
        }
      } else {
        // Standard revolution
        const p0 = new oc.gp_Pnt_3(points[0].x, points[0].y, points[0].z);
        const p1 = new oc.gp_Pnt_3(points[1].x, points[1].y, points[1].z);
        const e0 = new oc.BRepBuilderAPI_MakeEdge_3(p0, p1);
        const makeWire = new oc.BRepBuilderAPI_MakeWire_2(e0.Edge());
        p0.delete();
        p1.delete();
        e0.delete();

        
        for (let i = 1; i < points.length - 1; i++) {
          const pi = new oc.gp_Pnt_3(points[i].x, points[i].y, points[i].z);
          const pi1 = new oc.gp_Pnt_3(points[i+1].x, points[i+1].y, points[i+1].z);
          const makeEdge = new oc.BRepBuilderAPI_MakeEdge_3(pi, pi1);
          if (makeEdge.IsDone()) {
            makeWire.Add_1(makeEdge.Edge());
          }
          pi.delete();
          pi1.delete();
          makeEdge.delete();
        }
        const wire = makeWire.Wire();


        
        let profile: any = wire;
        const isClosed = points[0].x === points[points.length-1].x && points[0].y === points[points.length-1].y && points[0].z === points[points.length-1].z;
        if (isClosed) {
          const faceMaker = new oc.BRepBuilderAPI_MakeFace_2(wire);

          if (faceMaker.IsDone()) {
            profile = faceMaker.Face();
          }
          faceMaker.delete();
        }


        const builder = new oc.BRepPrimAPI_MakeRevol_2(profile, revAxis, angleRad);
        resultShape = builder.Shape();

        makeWire.delete();
        wire.delete();
        builder.delete();
      }

      revAxis.delete();

      if (!resultShape) {
        throw new Error("Failed to create revolve shape.");
      }

      // Tessellate and get geometry data
      const geometryData = shapeToBufferGeometryData(resultShape, oc, deflection);
      resultShape.delete();

      self.postMessage({ type: 'createRevolve', success: true, payload: geometryData, id });
    } catch (error: any) {
      const errorMessage = error.message || error.toString() || 'Unknown error';
      self.postMessage({ type: 'createRevolve', success: false, error: errorMessage, id });
    }
  }
}


// eslint-disable-next-line @typescript-eslint/no-explicit-any
function shapeToBufferGeometryData(shape: any, oc: any, linearDeflection: number = 0.1) {
  // Triangulate the shape
  new oc.BRepMesh_IncrementalMesh_2(shape, linearDeflection, false, 0.5, false);

  const positions: number[] = [];
  const indices: number[] = [];
  let vertexOffset = 0;

  // Explore all faces
  const explorer = new oc.TopExp_Explorer_2(shape, oc.TopAbs_ShapeEnum.TopAbs_FACE, oc.TopAbs_ShapeEnum.TopAbs_SHAPE);
  
  while (explorer.More()) {
    const faceShape = explorer.Current();
    
    // Guard against non-face shapes
    if (faceShape.ShapeType() !== oc.TopAbs_ShapeEnum.TopAbs_FACE) {
      explorer.Next();
      continue;
    }
    
    const face = oc.TopoDS.Face_1(faceShape);

    const location = new oc.TopLoc_Location_1();
    const triangulation = oc.BRep_Tool.Triangulation(face, location);

    if (!triangulation.IsNull()) {
      const trsf = location.Transformation();
      const tri = triangulation.get();
      
      // Extract Nodes (Vertices)
      const nbNodes = tri.NbNodes();
      for (let i = 1; i <= nbNodes; i++) {
        const pnt = tri.Node(i);
        pnt.Transform(trsf); // Apply face transformation
        positions.push(pnt.X(), pnt.Y(), pnt.Z());
      }

      // Extract Triangles
      const nbTriangles = tri.NbTriangles();
      const orientation = face.Orientation_1();
      
      for (let i = 1; i <= nbTriangles; i++) {
        const triangle = tri.Triangle(i);
        const n1 = triangle.Value(1);
        let n2 = triangle.Value(2);
        let n3 = triangle.Value(3);

        // Handle face orientation for backface culling
        if (orientation !== oc.TopAbs_Orientation.TopAbs_FORWARD) {
          [n2, n3] = [n3, n2];
        }

        indices.push(n1 + vertexOffset - 1, n2 + vertexOffset - 1, n3 + vertexOffset - 1);
      }
      vertexOffset += nbNodes;
    }
    explorer.Next();
  }

  return { positions, indices };
}
