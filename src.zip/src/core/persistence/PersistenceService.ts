import { DatabaseService } from './DatabaseService'
import { ShapeCacheDB } from './ShapeCacheDB'
import { EntitySerializer } from './EntitySerializer'
import { Document } from '../model/Document'
import { Solid3D } from '../model/Solid3D'
import { OpenCascadeService } from '../io/OpenCascadeService'
import { v4 as uuidv4 } from 'uuid'

export class PersistenceService {
  private db: DatabaseService
  private cache: ShapeCacheDB
  private occ: OpenCascadeService

  constructor() {
    this.db = DatabaseService.getInstance()
    this.cache = ShapeCacheDB.getInstance()
    this.occ = OpenCascadeService.getInstance()
  }

  async init(): Promise<void> {
    await this.db.init()
    await this.cache.init()
  }

  async saveDocument(doc: Document, name: string): Promise<string> {
    const projectId = doc.id || uuidv4()
    doc.id = projectId // ensure doc has ID

    // 1. Save project metadata
    await this.db.upsertProject({
      id: projectId,
      name,
      createdAt: (doc as any).createdAt || Date.now(),
      updatedAt: Date.now(),
      settings: {
        units: doc.units,
        facetres: doc.facetres,
        dimtoh: doc.dimtoh,
        dimtad: doc.dimtad,
        currentLayer: doc.layers.getCurrentLayer().name,
        currentElevation: doc.currentElevation,
        currentThickness: doc.currentThickness,
        idCounters: doc.getIdCounters() // Bug 4 fix
      }
    })

    // 2. Save layers
    const layerRows = doc.layers.listLayers().map(l => ({
      id: `${projectId}::${l.name}`,
      projectId,
      name: l.name,
      color: l.color,
      linetype: l.linetype,
      lineWeight: l.lineWeight,
      isVisible: l.isVisible,
      isFrozen: l.isFrozen,
      isLocked: l.isLocked
    }))
    await this.db.bulkUpsertLayers(layerRows)

    // 3. Save entities
    const entityRows: object[] = []
    for (const ent of doc.entities.values()) {
      entityRows.push(EntitySerializer.serialize(ent, projectId))

      // If it's a 3D solid without creation params (e.g. boolean result),
      // we must save its BREP data to the cache DB.
      if (ent instanceof Solid3D && !(ent as any).creationParams) {
        try {
          const brepBytes = await this.occ.exportBRep(ent.id)
          this.cache.saveBRep(ent.id, projectId, brepBytes)
        } catch (e) {
          console.error(`[Persistence] Failed to export BREP for ${ent.id}:`, e)
        }
      }

      // Always save tessellation cache for fast loading
      if (ent instanceof Solid3D && ent.positions.length > 0) {
        this.cache.saveTessellation(ent.id, projectId, ent.positions, ent.indices, 0.1) // default deflection
      }
    }
    await this.db.bulkUpsertEntities(entityRows)

    // 4. Update file history
    this.cache.upsertHistory(projectId, name)

    return projectId
  }

  async loadDocument(projectId: string, doc: Document): Promise<void> {
    const proj = await this.db.getProject(projectId)
    if (!proj) throw new Error(`Project ${projectId} not found`)

    doc.id = projectId
    doc.units = proj.settings.units
    doc.facetres = proj.settings.facetres
    doc.dimtoh = proj.settings.dimtoh
    doc.dimtad = proj.settings.dimtad
    doc.currentElevation = proj.settings.currentElevation
    doc.currentThickness = proj.settings.currentThickness
    if (proj.settings.idCounters) {
      doc.restoreIdCounters(proj.settings.idCounters) // Bug 4 fix
    }

    // Load layers
    const layers = await this.db.getLayersForProject(projectId)
    for (const l of layers) {
      if (l.name !== "0") {
        doc.layers.createLayer(l.name, l.color, l.linetype, l.lineWeight);
      }
      const added = doc.layers.getLayer(l.name);
      if (added) {
        added.isVisible = l.isVisible;
        added.isFrozen = l.isFrozen;
        added.isLocked = l.isLocked;
      }
    }
    if (proj.settings.currentLayer) {
      doc.layers.setCurrentLayer(proj.settings.currentLayer);
    }

    // Load entities
    const entRows = await this.db.getEntitiesForProject(projectId)
    doc.clear() // clear existing if any

    for (const row of entRows) {
      const ent = EntitySerializer.deserialize(row)

      if (ent instanceof Solid3D) {
        // Try to load tessellation first for instant display
        const tess = this.cache.loadTessellation(ent.id, projectId)
        if (tess) {
          ent.positions = tess.positions
          ent.indices = tess.indices
        }

        // Rebuild geometry in worker if it's a primitive or from BREP
        if (ent.creationParams) {
          // It will be rebuilt by IOHandler or specific command on load
          // But we can also do it here or trigger it.
          // PRD implies IOHandler handles primitive rebuilding in Bug 1.
        } else {
          // It's a boolean or complex shape — load BREP
          const brep = this.cache.loadBRep(ent.id, projectId)
          if (brep) {
            try {
              await this.occ.importBRep(ent.id, brep)
              // If tessellation was missing, we should compute it now.
              // For now we assume tessellation was cached.
            } catch (e) {
              console.error(`[Persistence] Failed to import BREP for ${ent.id}:`, e)
            }
          }
        }
      }

      doc.addEntity(ent)
    }
  }

  getHistory(): any[] {
    return this.cache.getHistory()
  }
}
