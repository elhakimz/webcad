import { Command, CommandResponse } from "./types"
import { UnitsConfig, IDocument } from "../model/Document"

export class ElevCommand implements Command {
  getPrompt(doc?: IDocument): string {
    const elev = doc ? doc.currentElevation : 0;
    return `New current elevation <${elev}>:`;
  }

  onInput(text: string, _id: string, _units: UnitsConfig, _pickPt?: { x: number, y: number }, doc?: IDocument): CommandResponse | undefined {
    const val = text.trim();
    
    if (val === "") {
      const current = doc ? doc.currentElevation : 0;
      return `Current elevation is ${current}.`;
    }

    const num = parseFloat(val);
    if (!isNaN(num)) {
      return { action: "elevationSet", value: num };
    }
    
    return "Invalid elevation value. Command aborted.";
  }

  onPoint(_x: number, _y: number, _id: string, _units: UnitsConfig): CommandResponse {
    return "ELEV command expects text input.";
  }
}
